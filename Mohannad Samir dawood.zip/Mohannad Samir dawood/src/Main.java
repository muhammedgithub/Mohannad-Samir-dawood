

class Account{  
		int acc_no;  
		String name;  
		float amount;
		long phone;
		String city;
     //Method to initialize object  
		void insert(int a,String n,float amt ,long ph ,String ci){  
		acc_no=a;  
		name=n;  
		amount=amt;
		phone=ph;
		city=ci;
		}  
		//deposit method  
		void deposit(float amt){  
		amount=amount+amt;  
		System.out.println(amt+" deposited");  
		}
		void city (String ci){  
			city = city+ci;  
			System.out.println(ci+"   city");  
			}
		void  phone(long ph){
			phone = phone+ph;
			System.out.println(ph+ "    phone");
			
		}
		
		//withdraw method  
		void withdraw(float amt){  
		if(amount<amt){  
		System.out.println("Insufficient Balance");  
		}else{  
		amount=amount-amt;  
		System.out.println(amt+" withdrawn");  
		}  
		}  

	    //method to check the balance of the account  
		void checkBalance(){System.out.println("Balance is: "+amount);}  
		//method to display the values of an object  
		void display(){System.out.println(acc_no+" "+name+" "+amount);}  
} 

//Creating a test class to deposit and withdraw amount  


public class Main {
	
	public static void main(String[] args){  
		Account a1=new Account();  
		a1.insert(832345,"Mohanad",3000, 0,"");  
		a1.display();  
		a1.checkBalance();  
		a1.deposit(40000);  
		a1.checkBalance();  
		a1.withdraw(15000);  
		a1.checkBalance();
		a1.phone(995566);
		a1.city("Baghdad");
		System.out.println("===========================");
		
		a1.insert(732344,"Sami",2000, 0,"");  
		a1.display();  
		a1.checkBalance();  
		a1.deposit(30000);  
		a1.checkBalance();  
		a1.withdraw(1000);  
		a1.checkBalance();
		a1.phone(123456);
		a1.city("Erbli");
		}

}






